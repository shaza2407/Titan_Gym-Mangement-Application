# app/main.py
from fastapi import FastAPI
from sqlalchemy import text
from app.routers import auth
from app.routers import training_plan
from app.routers import achievements   # NEW
from app.routers import checkin        # NEW

app = FastAPI(title="Titan Gym Management System")


@app.get("/")
def read_root():
    return {"message": "Welcome to my FastAPI backend"}


app.include_router(auth.router)
app.include_router(training_plan.router)
app.include_router(achievements.router)   # NEW  → /achievements/
app.include_router(checkin.router)        # NEW  → /checkin/