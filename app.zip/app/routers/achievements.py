# app/routers/achievements.py
"""
Endpoints
─────────
GET  /achievements/          – Return all badges + live progress for the current client
POST /achievements/recalculate – Force a full recalculation (admin / debug use)

Progress is calculated live from real DB data every time the client opens the screen.
"""

from datetime import datetime, timezone, timedelta
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, extract

from app.database import get_session
from app.dependencies.auth import get_current_user
from app.models.client import Client
from app.models.check_in import CheckIn
from app.models.client_class_enrollment import ClientClassEnrollment
from app.models.class_session import ClassSession
from app.models.training_plan import TrainingPlan
from app.models.achievement import Achievement
from app.models.client_achievement import ClientAchievement
from app.schemas.achievement_schemas import AchievementProgressResponse

router = APIRouter(prefix="/achievements", tags=["Achievements"])


# ── Helper: resolve clientID ──────────────────────────────────────────────────

async def _get_client(current_user, db: AsyncSession) -> Client:
    result = await db.execute(
        select(Client).where(Client.userID == int(current_user.userID))
    )
    client = result.scalar_one_or_none()
    if not client:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Only clients can view achievements."
        )
    return client


# ── Progress engine ───────────────────────────────────────────────────────────

async def _compute_progress(client_id: int, db: AsyncSession) -> dict[str, int]:
    """
    Returns a dict mapping achievement key → current progress integer.
    Add new achievements here if you ever expand the badge catalog.
    """
    now = datetime.now(timezone.utc)
    month_start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)

    # ── 1. Monthly Champion: check-ins this calendar month ────────────────────
    monthly_result = await db.execute(
        select(func.count(CheckIn.checkInID)).where(
            CheckIn.clientID == client_id,
            CheckIn.checked_in_at >= month_start,
        )
    )
    monthly_visits = monthly_result.scalar() or 0

    # ── 2. Class Enthusiast: distinct class sessions attended ─────────────────
    class_result = await db.execute(
        select(func.count(ClientClassEnrollment.sessionID.distinct())).where(
            ClientClassEnrollment.clientID == client_id
        )
    )
    distinct_classes = class_result.scalar() or 0

    # ── 3. Early Bird: check-ins where hour < 7 ───────────────────────────────
    early_result = await db.execute(
        select(func.count(CheckIn.checkInID)).where(
            CheckIn.clientID == client_id,
            CheckIn.check_in_hour < 7,
        )
    )
    early_mornings = early_result.scalar() or 0

    # ── 4. Consistency King: current consecutive-day streak ───────────────────
    streak = await _compute_streak(client_id, db)

    # ── 5. Social Butterfly: group class enrollments ──────────────────────────
    group_result = await db.execute(
        select(func.count(ClientClassEnrollment.enrollmentID)).where(
            ClientClassEnrollment.clientID == client_id,
            ClientClassEnrollment.is_group_class == 1,
        )
    )
    group_classes = group_result.scalar() or 0

    # ── 6. Goal Crusher: completed training plans ─────────────────────────────
    # A plan is "complete" if it was created more than (weeks * 7) days ago.
    plans_result = await db.execute(
        select(TrainingPlan).where(TrainingPlan.clientID == client_id)
    )
    all_plans = plans_result.scalars().all()
    completed_plans = sum(
        1 for p in all_plans
        if p.created_at and p.weeks and
        (now - p.created_at.replace(tzinfo=timezone.utc)).days >= p.weeks * 7
    )

    return {
        "monthly_champion": monthly_visits,
        "class_enthusiast": distinct_classes,
        "early_bird":       early_mornings,
        "consistency_king": streak,
        "social_butterfly": group_classes,
        "goal_crusher":     completed_plans,
    }


async def _compute_streak(client_id: int, db: AsyncSession) -> int:
    """Count how many consecutive calendar days the client has checked in (up to today)."""
    result = await db.execute(
        select(CheckIn.checked_in_at)
        .where(CheckIn.clientID == client_id)
        .order_by(CheckIn.checked_in_at.desc())
    )
    rows = result.scalars().all()
    if not rows:
        return 0

    # Collect unique check-in dates
    unique_dates = sorted(
        {r.date() if hasattr(r, "date") else r.replace(tzinfo=None).date() for r in rows},
        reverse=True,
    )
    today = datetime.now(timezone.utc).date()
    if unique_dates[0] < today - timedelta(days=1):
        return 0  # Last check-in was 2+ days ago — streak broken

    streak = 0
    expected = today
    for d in unique_dates:
        if d == expected or d == expected - timedelta(days=1):
            streak += 1
            expected = d - timedelta(days=1)
        else:
            break
    return streak


# ── GET /achievements/ ────────────────────────────────────────────────────────

@router.get(
    "/",
    response_model=list[AchievementProgressResponse],
    summary="Get all achievements with live progress for the authenticated client",
)
async def get_achievements(
    current_user=Depends(get_current_user),
    db: AsyncSession = Depends(get_session),
):
    client = await _get_client(current_user, db)

    # Load all achievement definitions
    ach_result = await db.execute(select(Achievement).order_by(Achievement.achievementID))
    achievements = ach_result.scalars().all()

    # Load client's saved progress rows
    ca_result = await db.execute(
        select(ClientAchievement).where(ClientAchievement.clientID == client.clientID)
    )
    saved = {row.achievementID: row for row in ca_result.scalars().all()}

    # Compute live progress from real data
    live_progress = await _compute_progress(client.clientID, db)

    response = []
    for ach in achievements:
        current = live_progress.get(ach.key, 0)
        prev    = saved.get(ach.achievementID)
        is_unlocked = current >= ach.target
        unlocked_at = None

        # Persist progress + record unlock timestamp (upsert)
        if prev is None:
            ca = ClientAchievement(
                clientID      = client.clientID,
                achievementID = ach.achievementID,
                current_value = current,
                is_unlocked   = is_unlocked,
                unlocked_at   = datetime.now(timezone.utc) if is_unlocked else None,
            )
            db.add(ca)
            unlocked_at = ca.unlocked_at
        else:
            prev.current_value = current
            if is_unlocked and not prev.is_unlocked:
                prev.is_unlocked = True
                prev.unlocked_at = datetime.now(timezone.utc)
            unlocked_at = prev.unlocked_at

        response.append(AchievementProgressResponse(
            achievementID = ach.achievementID,
            key           = ach.key,
            name          = ach.name,
            description   = ach.description,
            icon_emoji    = ach.icon_emoji,
            target        = ach.target,
            unit          = ach.unit,
            current_value = current,
            percent       = min(100, round((current / ach.target) * 100)),
            is_unlocked   = is_unlocked,
            unlocked_at   = unlocked_at,
        ))

    await db.commit()
    return response
