# app/models/check_in.py
from sqlalchemy import Column, Integer, ForeignKey, DateTime, String
from sqlalchemy.sql import func
from app.database import Base


class CheckIn(Base):
    """
    Records every time a client scans the QR code to check into a gym.
    Used to compute: Monthly Champion, Early Bird, Consistency King badges.
    """
    __tablename__ = "check_ins"

    checkInID   = Column("checkInID",  Integer, primary_key=True, index=True)
    clientID    = Column("clientID",   Integer, ForeignKey("clients.clientID"), nullable=False)
    gymID       = Column("gymID",      Integer, ForeignKey("gyms.gymID"),       nullable=False)
    checked_in_at = Column(
        "checked_in_at",
        DateTime(timezone=True),
        server_default=func.now(),
        nullable=False,
    )
    # Store the hour of check-in (0-23) for quick "Early Bird" queries (before 7 AM)
    check_in_hour = Column("check_in_hour", Integer, nullable=False)
