# app/models/achievement.py
from sqlalchemy import Column, Integer, String, Text, Boolean, JSON
from sqlalchemy.orm import relationship
from app.database import Base
import enum


class AchievementCategory(str, enum.Enum):
    """Categories for organizing achievements"""
    CHECKIN = "checkin"  # Related to gym check-ins
    CLASS = "class"  # Related to class attendance
    STREAK = "streak"  # Related to consistency streaks
    TRAINING = "training"  # Related to training plans
    SOCIAL = "social"  # Related to group activities
    EXPLORATION = "exploration"  # Related to trying new things
    MILESTONE = "milestone"  # Major milestone achievements


class AchievementDifficulty(str, enum.Enum):
    """Difficulty levels for achievements"""
    BRONZE = "bronze"  # Easy (1-10)
    SILVER = "silver"  # Medium (11-25)
    GOLD = "gold"  # Hard (26-50)
    PLATINUM = "platinum"  # Very hard (51-100)
    DIAMOND = "diamond"  # Extreme (100+)


class Achievement(Base):
    """
    Static catalog of all available badges/achievements.
    Seeded once at startup — never deleted by users.

    Includes tracking configuration for how to measure progress.
    """
    __tablename__ = "achievements"

    # Basic Info
    achievementID = Column("achievementID", Integer, primary_key=True, index=True)
    key = Column("key", String, unique=True, nullable=False)
    name = Column("name", String, nullable=False)
    description = Column("description", String, nullable=False)
    icon_emoji = Column("icon_emoji", String, nullable=True)

    # Achievement Configuration
    category = Column("category", String, nullable=False)  # From AchievementCategory
    difficulty = Column("difficulty", String, nullable=False)  # From AchievementDifficulty
    target = Column("target", Integer, nullable=False)  # Goal number (e.g., 20)
    unit = Column("unit", String, nullable=False)  # "visits", "classes", "days", etc.

    # Points & Rewards
    points = Column("points", Integer, default=10)  # Points awarded when unlocked
    badge_color = Column("badge_color", String, default="#FFD700")  # Hex color code

    # Tracking Configuration (NEW - for how to track progress)
    tracking_type = Column("tracking_type", String, nullable=False)
    """
    Types of tracking:
    - 'counter': Simple count (e.g., total check-ins)
    - 'streak': Consecutive days count
    - 'unique': Count distinct items (e.g., different classes)
    - 'percentage': Achievement based on completion percentage
    - 'composite': Multiple conditions (stored in tracking_config)
    """

    tracking_config = Column("tracking_config", JSON, nullable=True)
    """
    JSON configuration for complex tracking:
    Example for Monthly Champion:
    {
        "time_window": "monthly",  # daily, weekly, monthly, yearly, all_time
        "reset_frequency": "monthly",
        "min_threshold": 20
    }

    Example for Perfect Week:
    {
        "time_window": "weekly",
        "required_days_per_week": 5,
        "reset_frequency": "weekly"
    }
    """

    # Prerequisites (achievements that must be unlocked first)
    prerequisite_key = Column("prerequisite_key", String, nullable=True)

    # Hidden achievements (show only after reaching certain progress)
    is_hidden = Column("is_hidden", Boolean, default=False)
    reveal_at_percentage = Column("reveal_at_percentage", Integer, default=0)  # Show at X% progress

    # Relationships
    client_progress = relationship("ClientAchievement", back_populates="achievement")

    def get_progress_percentage(self, current_value: int) -> float:
        """Calculate progress percentage"""
        if self.target <= 0:
            return 0.0
        return min(100.0, (current_value / self.target) * 100)

    def get_difficulty_color(self) -> str:
        """Get color based on difficulty"""
        colors = {
            AchievementDifficulty.BRONZE: "#CD7F32",
            AchievementDifficulty.SILVER: "#C0C0C0",
            AchievementDifficulty.GOLD: "#FFD700",
            AchievementDifficulty.PLATINUM: "#E5E4E2",
            AchievementDifficulty.DIAMOND: "#B9F2FF"
        }
        return colors.get(self.difficulty, "#FFD700")