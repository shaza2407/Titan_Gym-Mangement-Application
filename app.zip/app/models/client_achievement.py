# app/models/client_achievement.py
from sqlalchemy import Column, Integer, ForeignKey, DateTime, Boolean, Float, JSON
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship
from app.database import Base


class ClientAchievement(Base):
    """
    Tracks each client's progress toward every achievement.
    Enhanced with streak data and historical tracking.
    """
    __tablename__ = "client_achievements"

    id = Column(Integer, primary_key=True, index=True)
    clientID = Column("clientID", Integer, ForeignKey("clients.clientID"), nullable=False)
    achievementID = Column("achievementID", Integer, ForeignKey("achievements.achievementID"), nullable=False)

    # Progress tracking
    current_value = Column("current_value", Integer, default=0, nullable=False)
    best_value = Column("best_value", Integer, default=0, nullable=False)  # Personal best
    progress_history = Column("progress_history", JSON, default=list)  # Track progress over time

    # Status
    is_unlocked = Column("is_unlocked", Boolean, default=False, nullable=False)
    unlocked_at = Column("unlocked_at", DateTime(timezone=True), nullable=True)

    # Streak specific (for streak achievements)
    current_streak = Column("current_streak", Integer, default=0)
    longest_streak = Column("longest_streak", Integer, default=0)
    last_activity_date = Column("last_activity_date", DateTime(timezone=True), nullable=True)

    # Timestamps
    updated_at = Column("updated_at", DateTime(timezone=True), onupdate=func.now())
    created_at = Column("created_at", DateTime(timezone=True), server_default=func.now())

    # Relationships
    achievement = relationship("Achievement", back_populates="client_progress")

    def to_dict(self):
        return {
            "id": self.id,
            "achievementID": self.achievementID,
            "current_value": self.current_value,
            "best_value": self.best_value,
            "is_unlocked": self.is_unlocked,
            "unlocked_at": self.unlocked_at,
            "current_streak": self.current_streak,
            "longest_streak": self.longest_streak,
            "progress_percentage": self.achievement.get_progress_percentage(
                self.current_value) if self.achievement else 0
        }