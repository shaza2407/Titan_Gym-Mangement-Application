# app/models/client_class_enrollment.py
from sqlalchemy import Column, Integer, ForeignKey, DateTime, String
from sqlalchemy.sql import func
from app.database import Base


class ClientClassEnrollment(Base):
    """
    Links a client to a class session they joined.
    Used for: Class Enthusiast (10 different classes) and
              Social Butterfly (5 group classes) badges.
    """
    __tablename__ = "client_class_enrollments"

    enrollmentID  = Column("enrollmentID", Integer, primary_key=True, index=True)
    clientID      = Column("clientID",     Integer, ForeignKey("clients.clientID"),    nullable=False)
    sessionID     = Column("sessionID",    Integer, ForeignKey("class_sessions.id"),   nullable=False)
    enrolled_at   = Column(
        "enrolled_at",
        DateTime(timezone=True),
        server_default=func.now(),
        nullable=False,
    )
    # Track whether the class was a group class (for Social Butterfly badge)
    is_group_class = Column("is_group_class", Integer, default=1)  # 1 = yes, 0 = no
