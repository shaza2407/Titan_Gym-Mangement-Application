from sqlalchemy import Column, Integer, String, Text, DateTime, ForeignKey, Enum as SQLEnum
from sqlalchemy.sql import func
from app.database import Base
import enum

class PlanStatus(str, enum.Enum):
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    ABANDONED = "abandoned"

class TrainingPlan(Base):

    __tablename__ = "training_plans"

    planID      = Column("planID",    Integer, primary_key=True, index=True)
    clientID    = Column("clientID",  Integer, ForeignKey("clients.clientID"), nullable=False)
    title       = Column(String,      nullable=False)
    goal        = Column(String,      nullable=False)
    level       = Column(String,      nullable=True)
    weeks       = Column(Integer,     nullable=True)
    plan_json   = Column(Text,        nullable=False)
    status      = Column(SQLEnum(PlanStatus), default=PlanStatus.IN_PROGRESS)  # ← ADD THIS
    completed_at = Column(DateTime(timezone=True), nullable=True)  # ← ADD THIS
    created_at  = Column(DateTime(timezone=True), server_default=func.now())
    updated_at  = Column(DateTime(timezone=True), onupdate=func.now())