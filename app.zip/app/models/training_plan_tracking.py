from sqlalchemy import Column, Integer, ForeignKey, Date, Float, String, DateTime, Boolean, UniqueConstraint
from sqlalchemy.sql import func
from app.database import Base
import enum


class WorkoutStatus(str, enum.Enum):
    PENDING = "pending"  # Not started yet
    IN_PROGRESS = "in_progress"  # Started but not completed
    COMPLETED = "completed"  # Fully completed
    PARTIAL = "partial"  # Partially completed (some exercises done)
    SKIPPED = "skipped"  # Skipped this day


class DayStatus(str, enum.Enum):
    NOT_STARTED = "not_started"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"


class TrainingPlanTracking(Base):
    """
    Tracks daily progress of training plans for achievement calculations.
    This allows fine-grained tracking for "Perfect Week", "Goal Crusher", etc.
    """
    __tablename__ = "training_plan_tracking"

    trackingID = Column(Integer, primary_key=True, index=True)
    clientID = Column(Integer, ForeignKey("clients.clientID"), nullable=False)
    planID = Column(Integer, ForeignKey("training_plans.planID"), nullable=False)

    # Daily tracking
    tracking_date = Column(Date, nullable=False)
    week_number = Column(Integer, nullable=False)
    day_number = Column(Integer, nullable=False)
    day_name = Column(String, nullable=True)  # "Monday", "Tuesday", etc.

    # Workout completion
    planned_exercises = Column(Integer, default=0)
    completed_exercises = Column(Integer, default=0)
    completion_percentage = Column(Float, default=0.0)
    status = Column(String, default=WorkoutStatus.PENDING)  # From WorkoutStatus

    # Exercise details (optional - store which exercises were completed)
    completed_exercises_list = Column(String, nullable=True)  # JSON string of completed exercise names
    exercises_data = Column(String, nullable=True)  # Full JSON of exercises with sets/reps completed

    # Time tracking
    started_at = Column(DateTime(timezone=True), nullable=True)
    completed_at = Column(DateTime(timezone=True), nullable=True)
    duration_minutes = Column(Integer, nullable=True)

    # Quality metrics
    intensity_rating = Column(Integer, nullable=True)  # 1-10 scale
    felt_difficulty = Column(Integer, nullable=True)  # 1-10 scale
    notes = Column(String, nullable=True)
    skipped_reason = Column(String, nullable=True)  # "sick", "busy", "injury", etc.

    # Streak tracking
    streak_day_number = Column(Integer, default=0)  # Consecutive workout day number

    # Timestamps
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    # Unique constraint to prevent duplicate tracking for same day
    __table_args__ = (
        UniqueConstraint('clientID', 'planID', 'tracking_date', name='unique_daily_tracking'),
    )

    def to_dict(self):
        return {
            "trackingID": self.trackingID,
            "date": self.tracking_date.isoformat() if self.tracking_date else None,
            "week": self.week_number,
            "day": self.day_number,
            "day_name": self.day_name,
            "progress": f"{self.completed_exercises}/{self.planned_exercises}",
            "completion_percentage": self.completion_percentage,
            "status": self.status,
            "duration_minutes": self.duration_minutes,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None
        }


class TrainingPlanWeekProgress(Base):
    """
    Aggregated weekly progress for faster queries
    Used for Perfect Week achievement and weekly summaries
    """
    __tablename__ = "training_plan_week_progress"

    weekProgressID = Column(Integer, primary_key=True, index=True)
    clientID = Column(Integer, ForeignKey("clients.clientID"), nullable=False)
    planID = Column(Integer, ForeignKey("training_plans.planID"), nullable=False)
    week_number = Column(Integer, nullable=False)

    # Aggregated stats
    total_days = Column(Integer, default=0)
    completed_days = Column(Integer, default=0)
    partially_completed_days = Column(Integer, default=0)
    skipped_days = Column(Integer, default=0)
    pending_days = Column(Integer, default=0)

    # Performance metrics
    average_completion = Column(Float, default=0.0)  # Average completion % across days
    total_exercises_completed = Column(Integer, default=0)
    total_planned_exercises = Column(Integer, default=0)
    total_duration_minutes = Column(Integer, default=0)

    # Week status
    week_status = Column(String, default=DayStatus.NOT_STARTED)
    is_perfect_week = Column(Boolean, default=False)  # All days completed with 100%

    # Date range
    week_start_date = Column(Date, nullable=False)
    week_end_date = Column(Date, nullable=False)

    # Timestamps
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    __table_args__ = (
        UniqueConstraint('clientID', 'planID', 'week_number', name='unique_week_progress'),
    )
